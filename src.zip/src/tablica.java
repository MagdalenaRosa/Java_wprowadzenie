public class tablica {
    public static void main(String[] args) {
        int [] tablica= new int[10] ;

        for (int i = 9; i >=0; i--){
            tablica[i] = i;
            System.out.println(tablica[i]);
    }
    }}
